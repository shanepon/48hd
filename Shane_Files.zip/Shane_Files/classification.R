####################################################
# Name: classification.R
# Author: Shane Pon
# Date: September 10
# Function: Attempts to classify and predict different classes of values (high, medium, low)
# Procedure: values are selected heuristically
#   Medium values: -3.3 <= x <= -2.3
#   High: x > -2.3
#   Low: x < -3.3
# Input: z_encoding.txt -> contains all the encoded sequences using Z-Scales as features
# Output: Results from knn, plot of optimal clusters, plot of predicted vs observed values,
#         summary of training tree performace, and table of misclassifications from tree model
# How to use: run the script and set the working directory

####################################################
# run KNN to find which points are most closely related 
setwd("/Users/shanepon/Desktop/Shane Files/7.) extreme_values")
library(dplyr)
library(tidyr) 
library(ggplot2) 
library(caret)
library(ggplot2)
library(tibble)
####################################################
# Assesses model performance
# create equal sized random samples of 2000
set.seed(9) 
rand.low <- as.vector(sample(1:2152, 2000))
rand.med <- as.vector(sample(1:59634, 2000))
rand.high <- as.vector(sample(1:4480, 2000))

zscale <- read.table("z_encoding.txt", header = TRUE) %>%
          rownames_to_column(., var = "rowname") 
colnames(zscale)[1] <- "sequence"

# Categorize data by magnitude 
zscale.low <- zscale %>% 
              filter(., observed > -4) %>% 
              filter(.,observed <= -3.3)
zscale.med <- zscale %>% 
                 filter(., observed > -4) %>%
                 filter(.,observed > -3.3) %>%
                 filter(., observed < -2.4)
zscale.high <- zscale %>% 
               filter(., observed > -4) %>% 
               filter(., observed >= -2.4)

# take random samples from ranges
zscale.low <- zscale.low[rand.low,]
zscale.med <- zscale.med[rand.med,]
zscale.high <- zscale.high[rand.high,]

zscale.low$class <- "low"
zscale.med$class <- "med"
zscale.high$class <- "high"

rm(rand.low)
rm(rand.med)
rm(rand.high)

zscale <- rbind(zscale.low, zscale.med) %>% rbind(., zscale.high)

# Run K-Nearest Neighbors model
control <- trainControl(method = "repeatedcv",  repeats = 3, search = "grid")
grid = expand.grid(k = c(5,7,9,11,13,15,17))
knn <- train(observed~., data = zscale[,2:14], method = "knn", 
             trControl = control, tuneGrid = grid,
             preProcess = c("center", "scale"))

results <- knn$results
print(results)
# plot error as a function of clusters
plot(knn, xlab = "# of clusters", main = "Error of KNN")
#####################################################
# Plotting predicted values
# Same process as above but with smaller sample of 25 
set.seed(9) 
rand.low <- as.vector(sample(1:2152, 25))
rand.med <- as.vector(sample(1:59634, 25))
rand.high <- as.vector(sample(1:4480, 25))

zscale <- read.table("z_encoding.txt", header = TRUE) %>%
  rownames_to_column(., var = "rowname") 
colnames(zscale)[1] <- "sequence"

zscale.low <- zscale %>% 
  filter(., observed > -4) %>% 
  filter(.,observed <= -3.3)
zscale.med <- zscale %>% 
  filter(., observed > -4) %>%
  filter(.,observed > -3.3) %>%
  filter(., observed < -2.4)
zscale.high <- zscale %>% 
  filter(., observed > -4) %>% 
  filter(., observed >= -2.4)

zscale.low <- zscale.low[rand.low,]
zscale.med <- zscale.med[rand.med,]
zscale.high <- zscale.high[rand.high,]

zscale.low$class <- "low"
zscale.med$class <- "med"
zscale.high$class <- "high"

rm(rand.low)
rm(rand.med)
rm(rand.high)

zscale <- rbind(zscale.low, zscale.med) %>% rbind(., zscale.high)

# Run KNN and compute predicted values
control <- trainControl(method = "repeatedcv",  repeats = 3, search = "grid")
grid = expand.grid(k = c(5,7,9,11,13,15,17))
knn <- train(observed~., data = zscale[,2:14], method = "knn", 
             trControl = control, tuneGrid = grid,
             preProcess = c("center", "scale"))
zscale$predicted <- predict(knn, zscale[,1:13], interval = "prediction")

# plot predicted vs observed
plot <- ggplot(zscale, aes(observed, predicted, col = class)) + 
        geom_point() + 
        geom_text(aes(label = sequence), hjust = 1.1, vjust = -1.3, size = 2.8) +
        ggtitle("Predicted vs Observed - KNN") + 
        theme(plot.title = element_text(hjust = 0.5))
print(plot)

####################################################
# Tree for classification of high, medium, and low 
library(tree)
# Random sample of 2000 and process data as abover
set.seed(3) 
rand.low <- as.vector(sample(1:2152, 2000))
rand.med <- as.vector(sample(1:59634, 2000))
rand.high <- as.vector(sample(4480, 2000))

zscale <- read.table("z_encoding.txt", header = TRUE) %>%
          rownames_to_column(., var = "rowname") 
colnames(zscale)[1] <- "sequence"

zscale.low <- zscale %>% 
              filter(., observed > -4) %>% 
              filter(.,observed <= -3.3)
zscale.med <- zscale %>% 
              filter(., observed > -4) %>%
              filter(.,observed > -3.3) %>%
              filter(., observed < -2.4)
zscale.high <- zscale %>% 
               filter(., observed > -4) %>% 
               filter(., observed >= -2.4)

zscale.low <- zscale.low[rand.low,]
zscale.med <- zscale.med[rand.med,]
zscale.high <- zscale.high[rand.high,]

zscale.low$class <- as.factor("low")
zscale.med$class <- as.factor("med")
zscale.high$class <- as.factor("high")

rm(rand.low)
rm(rand.med)
rm(rand.high)

zscale <- rbind(zscale.low, zscale.med) %>% rbind(., zscale.high)
set.seed(3)
inTrain <- sample(1:nrow(zscale), 0.8*nrow(zscale))
train.set <- zscale[inTrain,]
test.set <- zscale[-inTrain,]

# training tree, model performance, and tree plot
zscale.tree <- tree(class~. -sequence -observed, data = train.set)
summary(zscale.tree)
plot(zscale.tree)
text(zscale.tree)
title("Classification Tree for Bins")

# table showing correct and incorrect classifications
# Number of incorrect classifications are off the diagonal
# Correct classifications are on the diagonal
zscale.tree.pred <- predict(zscale.tree, test.set, type = "class")
table(zscale.tree.pred, test.set$class)