###############################################################
# Introduction
# Name: combinations.py
# Author: Shane Pon
# Date Written: July 13
# Function: Computer the number of times each combination of amino acids occurs
# Procedure: Generate all possible combinations using itertools.product
#            then use freq() function to count the number of times a combination occurs
# Input: peptides.txt, a text file containing all peptides
#        peptides.txt comes from the sequence column in MLinput.txt
# Output: The combination and number of times it occurs in each position printed
#         to the screen. That was then copy/pasted to a text file
# Usage: run the script and copy/past output
###############################################################
import itertools

# find frequency of combinations
letters = ['A', 'R', 'N', 'D', 'C', 'E', 'Q', 'G', 'H',
               'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W',
               'Y', 'V']
#recursive function will find frequency in each position
#i.e. first two letters, second two, last two
#recursively iterate through the sequence
def freq(combos, peptides, array): 
    index = len(combos)
    if index == 0:
        return
    else:
        if combos[index - 1] in peptides: #if combo found, print frequency
            print(combos[index - 1], peptides.count(combos[index - 1]))
            combos.pop() #done with that combo, move onto the next
            freq(combos, peptides, array)
        else:
            print(combos[index - 1], "0") #otherwise not found
            combos.pop()
            freq(combos, peptides, array)
        return


def main():
    file = open("peptides.txt", "r").readlines()
    text = []
    array = []
    letters = ['A', 'R', 'N', 'D', 'C', 'E', 'Q', 'G', 'H',
               'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W',
               'Y', 'V']
    for item in file:
        text.append(item[0:2])
        #text.append(item[1:3])    # need to append to text individually
        #text.append(item[2:4])    # can only have one of these 3 lines uncommented at a time
    acids = 'ARNDCEQGHILKMFPSTWYV'
    combos = list(map(''.join, itertools.product(acids, repeat=2)))
    combos.reverse() #reverse because it printed in reverse order intiailly
                     # .reverse() puts it beginning to end
    results = freq(combos, text, array)


main()
