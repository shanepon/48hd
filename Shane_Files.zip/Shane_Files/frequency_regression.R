#########################################################
# Name: frequency_regression.R
# Author: Shane Pon
# Date: July 18
# Function: Process information from combinations to build a regression model 
# Procedure: Taking combinations.csv, it adds the sequences as a column and includes
#            normalized values then those as predictors
# Input: MLinput.txt: text file with sequences and their associated value
#        combinations.csv: excel file with the combinations and their normalized values, freq, and                position  
# Output: summary of the model  
# How to use: Only need to run section labelled "#regression model" as everything before it
# processes the text file for usage in the model




#########################################################
# don't forget to set working directory 
# This section only used the loops to get the text file
# can go to next section now that text file is written
setwd("/.../.../...")
library(tidyr)
library(dplyr)

# Purpose of this file is to create a matrix that encodes the peptides 
# with their normalized combinational frequencies in each position 


# This is preparing the dataframes to work with 
MLinput <- read.table("MLinput.txt", header = TRUE, na.strings="")
MLinput <- data.frame(MLinput[order(MLinput$peptide),])

combos <- read.csv("combinations.csv", header=TRUE, na.strings="")
peptides <- as.matrix(MLinput) 
rm(MLinput)

#Create normalized encoded vectors
regression <- data.frame(matrix(data=NA, nrow=67278, ncol=4))
colnames(regression) <- c("amino acids", "position 1", "position 2", "position 3")
regression$"amino acids" <- peptides

#subset sequences based on position 
acids <- data.frame(matrix(data=NA, nrow=67278, ncol=3))
colnames(acids) <- c("position 1", "position 2", "position 3")
acids$"position 1" <- substring(peptides,1,2)
acids$"position 2" <- substring(peptides,2,3)
acids$"position 3" <- substring(peptides,3,4)
rm(peptides)

# filtered table with only position 1 and normalized values 
norm_values <- combos %>% filter(position == "position 1") %>% select(-freq, -position)

# next three loops take some time to run
index = 1
for (i in 1:400) { 
    while(norm_values[i,"combo"] == acids[index, "position 1"]) {
      # create "posisiton 1" column and insert its normalized value
      regression[index, "position 1"] <- norm_values[i, "normalized"]
      if(index < 67278){
      index = index + 1
      }
      else if (index == 67278) {
        break
      }
    }
}
rm(norm_values)

# complete same process for next two loops
# fill in regression table with position 2 normalized values
norm_values2 <- combos %>% filter(position == "position 2") %>% select(-freq, -position)
enum <- seq(1,67278)
acids <- as.data.frame(cbind(enum, acids))
acids <- acids[order(acids$"position 2"),]
new_matrix <- as.data.frame(matrix(data=NA, nrow=67278, ncol=3))
colnames(new_matrix) <-c("enum","position 2","norm")
new_matrix$enum <- enum
new_matrix$"position 2" <- acids[,"position 2"]

index = 1
system.time( 
  for (i in 1:400) { 
  while(norm_values2[i,"combo"] == acids[index, "position 2"]) {
    new_matrix[index, "norm"] <- norm_values2[i, "normalized"]
    if(index < 67278){
      index = index + 1
    }
    else if (index == 67278) {
      break
    }
  }
}
)
acids$norm <- new_matrix[,"norm"]
acids <- acids[order(acids$"enum"),]
regression$"position 2" <- acids$"norm"
rm(norm_values2)

# fill in regression table with position 3 normalized vales
norm_values3 <- combos %>% filter(position == "position 3") %>% select(-freq, -position)
acids$norm <- NA
acids <- acids[order(acids$"position 3"),]
new_matrix$norm <- NA
colnames(new_matrix) <-c("enum","position 3","norm")

index = 1
for (i in 1:400) { 
  while(norm_values3[i,"combo"] == acids[index, "position 3"]) {
    new_matrix[index, "norm"] <- norm_values3[i, "normalized"]
    if(index < 67278){
      index = index + 1
    }
    else if (index == 67278) {
      break
    }
  }
}
acids$norm <- new_matrix[,"norm"]
acids <- acids[order(acids$"enum"),]
regression$"position 3" <- acids$"norm"
rm(norm_values3)

write.table(regression, file = "frequency.txt", row.names = FALSE, col.names = TRUE)


##########################################################################################
# regression model 
table <- read.table("frequency.txt", header = TRUE)
model <- lm(amino.acids.number~position.1 + position.2 + position.3, table)
summary(model)
plot(model)

