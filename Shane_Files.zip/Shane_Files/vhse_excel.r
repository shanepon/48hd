##################################################################
# Name: vhse_excel.r 
# Author: Shane Pon
# Date: September 2
# Function: Produce predicted values and compile into table
# Input: nonzero_vhse.txt (vhse encoded sequences with zero values removed)
# Output: training/test set, and test set predictions
# Usage: Run script section by section after setting working directory


##################################################################
# create excel sheet with observed and predicted values 
setwd("/Users/shanepon/Desktop/Shane Files/6.) excel table")
#library(xlsx)
library(dplyr)
library(tibble)
library(caret)
library(kernlab)
library(randomForest)
# vhse has zero values already removed (values < -4)
vhse <- read.table("nonzero_vhse.txt", header = TRUE)

# divide data set 80% training 20% testing
set.seed(1)
rand.num <- as.vector(sample(1:66266,53013))

train_vhse <- vhse[rand.num,]
colnames(train_vhse)[33] <- "observed"
train_vhse$linear.pred <- NA 
train_vhse$svm.pred <- NA 
train_vhse$tree.pred <- NA 
train_vhse$knn.pred <- NA 


# create test set
test_vhse <- vhse[-rand.num,]
colnames(test_vhse)[33] <- "observed"


test_vhse$linear.pred <- NA 
test_vhse$svm.pred <- NA 
test_vhse$tree.pred <- NA 
test_vhse$knn.pred <- NA 


#################################################################################
# first supervised learning: linear regression 
vhse.lin.model <- lm(observed~., data = train_vhse[,1:33])
vhse.lin.predicted = predict.lm(vhse.lin.model, test_vhse[,1:32], interval = "prediction")
test_vhse[,"linear.pred"] <- vhse.lin.predicted[,1]


#################################################################################
# second supervised learning: support vector machines
library(e1071)
system.time(
  vhse.svm.model <- svm(observed~., data = train_vhse[,1:33])
)
vhse.svm.predicted <- predict(vhse.svm.model, test_vhse[,1:32], interval = "prediction")
test_vhse[,"svm.pred"] <- vhse.svm.predicted




#################################################################################
# third supervised learning: decision trees
library(rpart)
vhse.tree.model <- rpart(observed~., data = train_vhse[,1:33], method = "anova")
vhse.tree.predicted <- predict(vhse.tree.model, test_vhse[,1:32], interval = "prediction")
test_vhse[,"tree.pred"] <- vhse.tree.predicted

#################################################################################
# fourth supervised learning: k nearest neighbour
system.time(
  vhse.knn.model <- train(observed~., data = train_vhse[,1:33], method = "knn")
)
vhse.knn.predicted <- predict(vhse.knn.model, test_vhse[,1:32], interval = "prediction")
test_vhse[,"knn.pred"] <- vhse.knn.predicted
#################################################################################
# combine results into a table
vhse_results <- rbind(train_vhse, test_vhse)
write.table(vhse_results, "vhse_results.txt")

