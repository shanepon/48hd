##########################################################################
# Name: mdoels.r
# Author: Shane Pon
# Date: Late July
# Function: Fits different models to VHSE data to find best results
# Procedure: encodes all sequences with their VHSE values, i.e., one peptide is associated with a 
#            1x32 length row vector, then fits various models using that as regressors
# Input: encoded.txt -> contains 1x8 vectors for a single acid
#        MLinput_log.txt -> contains sequences and observed log values
# Output: model summaries and measures of their performance        
# Usage: run section by section after setting working directory






##########################################################################
setwd("/Users/shanepon/Desktop/Shane Files/machine learning")
library(dplyr)
library(ggplot2)
library(rpart)
library(e1071)
library(tree)
encoded <- read.table("encoded.txt", header=TRUE) 
rownames(encoded) <- encoded$amino.acid 
encoded <- encoded[-1]
MLinput_log <- read.table("MLinput_log.txt", header=TRUE)
vhse <- read.table("peptide_vhse.txt", header=TRUE)
vhse$log.value <- MLinput_log[,"log.value"]
vhse <- filter(vhse, log.value > -4) 
# data <- read.table("vhse.csv", header = TRUE)
# 80% of data set for training
set.seed(1)
rand.num <- as.vector(sample(1:66266,13253))
vhse <- vhse[-rand.num,]
rm(rand.num)


##########################################################################
# model and predicted values from model
model <- lm(log.value~., data = vhse)
data <- data.frame(predicted = numeric(53013),
                   observed = numeric(53013))
fit <-predict(model, vhse[,1:32], interval = "predict")
data[,"predicted"] <- fit[,1]
data$observed <- vhse$log.value
set.seed(2)
rand.num <- as.vector(sample(1:53013, 1000))
predicted <- data[rand.num,"predicted"]
observed <- data[rand.num,"observed"]

# polynomial model 
model <- lm(observed ~ poly(predicted,2), data)
plot(data$predicted, data$observed, main = "Observed vs Predicted")
lines(data$predicted, predict(lm(observed ~ poly(predicted,2), data = data)), 
              col = 'tomato')
summary(model)

# linear model 
model <- lm(observed ~ predicted, data = data)
summary(model)

rand.num <- as.vector(sample(1:53013, 1000))
predicted <- data[rand.num,"predicted"]
observed <- data[rand.num,"observed"]
plot(predicted, observed, main = "Observed vs Predicted")
abline(0,1, col = 'tomato', lwd = 3)

summary(model)



##########################################################################
# support vector machine
train <- data[rand.num,]
plot(train)
model <- lm(observed~predicted, train)
abline(model, col = 'tomato')

model_svm <- svm(observed ~ predicted, train)
pred <- predict(model_svm, train)
points(train$predicted, pred, col = "blue", pch = 4)
error <- model$residuals
lm_error <- sqrt(mean(error^2))

error_2 <- train$predicted - pred
svm_error <- sqrt(mean(error_2^2))

plot(model_svm, data)
title(main = "Support Vector Machine")




##########################################################################
# Subset regression 
library(MASS)
model <- lm(log.value ~ ., data = vhse)
step <- step(model, diretion = "backward")



##########################################################################
# principal component analysis
# 80% of data set for training
set.seed(1)
rand.num <- as.vector(sample(1:66266,13253))
vhse <- vhse[-rand.num,]
rm(rand.num)

pca <- princomp(vhse[,-33], cor = TRUE)
summary(pca)

##########################################################################
# regression tree
tree.model <- tree(log.value~., data = vhse)
plot(tree.model)
text(tree.model, cex = 0.75)
title(main = "Regression Tree for Multiple Linear Model")
summary(tree.model)
##########################################################################
