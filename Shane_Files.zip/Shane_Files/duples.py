###############################################################
# Name: duples.py
# Author: Shane Pon
# Date: Early July
# Function: Finds repeating acids 
# Input: MLinput.txt (sequences with observed values) 
# Output: three files (repeatX.txt) that contain the counts of repeated acid
# Usage: run the script






###############################################################
# Everything below this comment finds the frequency
# Of two repeating acids in each position

# THIS IS ALSO NOT WHAT I WAS SUPPOSED TO DO
# KEEP THIS FILE TO REUSE THE CODE

MLinput = open("MLinput.txt", "r").readlines()

array1 = []
array2 = []
array3 = []

# Separate peptide into 2 character strings
# append to array based on position

i = 0
while i < len(MLinput):
    value1 = MLinput[i].split(" ")
    value2 = MLinput[i].split(" ")
    value3 = MLinput[i].split(" ")
    array1.append(value1[0][0:2])
    array2.append(value2[0][1:3])
    array3.append(value3[0][2:4])
    i += 1

total_array = []
total_array.extend(array1)
total_array.extend(array2)
total_array.extend(array3)

repeats = ['AA', 'RR', 'NN', 'DD', 'CC', 'EE', 'QQ', 'GG',
           'HH', 'OO', 'II', 'LL', 'KK', 'MM', 'FF', 'PP',
           'UU', 'SS', 'TT', 'WW', 'YY', 'VV']

count1 = open("repeat1.txt", "w")
count2 = open("repeat2.txt", "w")
count3 = open("repeat3.txt", "w")
total_count = open("total_repeat.txt", "w")

# using repeats, count instances of repeat in each array

for repeat in repeats:
    if repeat in array1:
        count1.write(repeat)
        count1.write(" ")
        count1.write("found ")
        count1.write(str(array1.count(repeat)))
        count1.write(" times")
        count1.write("\n")

    if repeat in array2:
        count2.write(repeat)
        count2.write(" ")
        count2.write("found ")
        count2.write(str(array2.count(repeat)))
        count2.write(" times")
        count2.write("\n")

    if repeat in array3:
        count3.write(repeat)
        count3.write(" ")
        count3.write("found ")
        count3.write(str(array3.count(repeat)))
        count3.write(" times")
        count3.write("\n")

    else:
        count1.write(repeat)
        count1.write(" ")
        count1.write("not found\n")
        count2.write(repeat)
        count2.write(" ")
        count2.write("not found\n")
        count3.write(repeat)
        count3.write(" ")
        count3.write("not found\n")

for repeat in repeats:
    if repeat in total_array:
        total_count.write(repeat)
        total_count.write(" ")
        total_count.write("found ")
        total_count.write(str(total_array.count(repeat)))
        total_count.write(" times")
        total_count.write("\n")

count1.close()
count2.close()
count3.close()
