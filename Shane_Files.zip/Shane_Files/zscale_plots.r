##########################################################################
# Name: zscale_plots.r
# Author: Shane Pon
# Date: Late July 
# Function: Takes 10 random samples of 1000 points and plots predicted vs observed 
#           to see if behavior is all the same for each sample
# Input: encoded.txt -> contains acids and their associated VHSE vales
#       MLinput_log.txt -> sequences and their observed log values
#       peptide_vhse.txt -> sequences that are fully encoded with VHSE values
#       zscale.txt -> acids and their associted z-scale values (1x3 vector/acid)
#       vhse.csv -> vhse observed and predicted values
# Output: Plots of predicted vs observed values
# How to use: run script after setting the working directory but
#             do not need to run "#preprocess zscale data" 
##########################################################################
# script for principal component analysis (pca)
##########################################################################
# preprocess data and save vhse vectors to file 
# titled vhse_nonzero.txt 
# does not contain any zero values 
setwd("/Users/shanepon/Desktop/Shane Files/5.) machine learning")
library(dplyr)
library(ggplot2)
library(rpart)
library(e1071)
library(stats)
library(tree)
encoded <- read.table("encoded.txt", header=TRUE) 
rownames(encoded) <- encoded$amino.acid 
encoded <- encoded[-1]
MLinput_log <- read.table("MLinput_log.txt", header=TRUE)


##########################################################################
# Preprocess zscale data
zscale <- read.table("zscale.txt", header = TRUE)
rownames(zscale) <- zscale$amino.acid
zscale <- zscale[,-1]

z <- data.frame(z11=numeric(67278),
                z12=numeric(67278),
                z13=numeric(67278),
                z21=numeric(67278),
                z22=numeric(67278),
                z23=numeric(67278),
                z31=numeric(67278),
                z32=numeric(67278),
                z33=numeric(67278),
                z41=numeric(67278),
                z42=numeric(67278),
                z43=numeric(67278))
z$log.value <- MLinput_log[,"log.value"]

i <- 1
system.time(while (i <= 67278) {
  acid <- as.character(MLinput_log[i,1])
  splitted <- strsplit(acid,"") %>% unlist()
  first <- splitted[1]
  second <- splitted[2]
  third <- splitted[3]
  fourth <- splitted[4]
  first <- zscale[first,]
  second <- zscale[second,]
  third <- zscale[third,]
  fourth <- zscale[fourth,]
  z[i,1:3] <- first[1,]
  z[i,4:6] <- second[1,]
  z[i,7:9] <- third[1,]
  z[i,10:12] <- fourth[1,]
  i <- i+1
})
z$log.value <- MLinput_log$log.value
rownames(z) <- MLinput_log$peptide
write.table(z, "z.txt", row.names = TRUE)

##########################################################################
# use zscales to for modelling
z = read.table("z.txt", header = TRUE)
model <- lm(log.value ~ ., data = z)
data <- data.frame(predicted = numeric(1000),
                   observed = numeric(1000))

# first sample
set.seed(2)
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)
summary(model)



# second sample
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)


# third sample
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)


# fourth sample
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)


# fifth sample
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)


# sixth sample
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)


# seventh sample
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)


# eighth sample
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)


# ninth sample
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)


# tenth sample
rand.num <- as.vector(sample(1:53013, 1000))
data[,"observed"] <- z[rand.num, "log.value"]
prediction <- predict(model, z[rand.num,1:12], interval = "predict")
data[,"predicted"] <- prediction[,1]
predicted <- data[,"predicted"]
observed <- data[,"observed"]

plot(data$predicted, data$observed, xlab = 'predicted',
     ylab = 'observed', main = 'Observed vs Predicted - z scale')
abline(lm(observed~predicted), col = 'tomato', lwd = 3)





