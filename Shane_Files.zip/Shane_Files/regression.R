###############################################################
# Name: regression.R
# Author: Shane Pon
# Date: Mid-Late July
# Function: Generates two models: the full model and the second reduced model with collinear fators
#           taken out
# Input: encoded.txt (acids encoded by VHSE and written by hand), MLinput_log.txt (sequences with log observed valuesby processing log values),
#        peptide_vhse.txt (sequences and they VHSE encoding)
# Output: summary of model performance
# Usage: Run script after setting working directory 

###############################################################
# Build linear regression model 
setwd("")
library(dplyr)
library(ggplot2)

encoded <- read.table("encoded.txt", header=TRUE) 
rownames(encoded) <- encoded$amino.acid 
encoded <- encoded[-1]
MLinput_log <- read.table("MLinput_log.txt", header=TRUE)

peptide <- as.data.frame(matrix(nrow=67278,ncol=32))
vect <- MLinput_log[,"peptide"]
rownames(peptide) <- vect

vhse <- read.table("peptide_vhse.txt", header=TRUE)
vhse$log.value <- MLinput_log[,"log.value"]

i <- 1
j <- 1
while (i <= 67278) {
  while (j <= 4) {
    acid <- as.character(MLinput_log[i,"peptide"])
    splitted <- strsplit(acid,"") %>% unlist()
    rowname <- splitted[j]
    if (j == 1) {
      peptide[acid,1:8] <- encoded[rowname,]
    }
    else if (j == 2) {
      peptide[acid,9:16] <- encoded[rowname,]
    }
    else if (j == 3) {
      peptide[acid,17:24] <- encoded[rowname,]
    }
    else if (j == 4) {
      peptide[acid,25:32] <- encoded[rowname,]
    }
    j = j + 1
  }
  i = i + 1
  j = 1
}

# original model with multicollinearity 
model <-lm(log.value~.,
           data=vhse)
predicted <- predict(model, newdata = MLinput_log[,"log.value"],interval = "prediction")
plot(model)
summary(model)  

library(usdm)
vif(model) 
# Reduced model 
vif <- vhse[,c(-1,-2,-3,-6,-9,-10,-11,-14,-17,-18,-19,-22,-25,-26,-27,-30)]
model <- lm(log.value~VHSE4+VHSE5+VHSE7+VHSE8+VHSE12+VHSE13+VHSE15+VHSE16+
            VHSE20+VHSE21+VHSE23+VHSE24+VHSE28+VHSE29+VHSE31+VHSE32, data=vif)
plot(model)
summary(model)












