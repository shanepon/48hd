#######################################################
# Name: model.r
# Author: Shane Pon
# Date: mid-July
# Function: Runs partial least squares regression 
# Input: encoded.txt (acids encoded with VHSE), MLinput_log.txt (sequences with log observed values), 
#                    peptide_vhse.txt (sequences encoded with VHSE)
# Output: summary of model performance 
# Run the script after setting working directory



#######################################################
# Build linear regression model 
setwd("/Users/shanepon/Desktop/Shane Files/4.) regression")
library(dplyr)
library(ggplot2)
library(usdm)
library(pls)
encoded <- read.table("encoded.txt", header=TRUE) 
rownames(encoded) <- encoded$amino.acid 
encoded <- encoded[-1]
MLinput_log <- read.table("MLinput_log.txt", header=TRUE)
vhse <- read.table("peptide_vhse.txt", header=TRUE)
vhse$log.value <- MLinput_log[,"log.value"]

# 80% of data set for training
set.seed(1)
#use half of data set for training 
rand.num <- as.vector(sample(1:67278,13455))
vhse <- vhse[-rand.num,]

model <-lm(log.value~.,
           data=vhse)
par(mfrow=c(1,1))
plot(model)
summary(model)

# Reduced model 
model <- lm(log.value~VHSE4+VHSE5+VHSE7+VHSE8+VHSE12+VHSE13+VHSE15+VHSE16+
              VHSE20+VHSE21+VHSE23+VHSE24+VHSE28+VHSE29+VHSE31+VHSE32, data=vhse)
plot(model)
summary(model)

# Partial least squares
pls.fit <- plsr(log.value~., data = vhse, scale=TRUE, validation = "CV")
summary(pls.fit)
plot(RMSEP(pls.fit), legendpos = 'topright', main = "Root Mean Square Error")


# use components instead of cv
pls.fit <-plsr(log.value~., data = vhse, scale = TRUE, ncomp = 5)
summary(pls.fit)
plot(pls.fit)





