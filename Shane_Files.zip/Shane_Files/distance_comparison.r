######################################################################
# Name: distance_comparison.r
# Author: Shane Pon
# Date: September 3
# Function: Generates residual plots from each method for both descriptors and 
#           for both descriptors and superimposes them on each other 
# Input: z_test.txt (test data from z-scale encoding)
#        vhse_test.txt  
# Output: Plots for the absolute residual values imposed on each other 
#         for comparison and summaries of the residuals
# Run the script section by section after setting the working directory
######################################################################
# finds how similar two models are by taking the difference (distance)
# between the predicted values and the observed values
# closer the values are to y = 0, the better the model fits
######################################################################
# linear model 
setwd("/Users/shanepon/Desktop/Shane Files/6.) excel table")
library(dplyr)
library(tidyr)
library(gridExtra)
z.test <- read.table("z_test.txt", header = TRUE)
vhse.test <- read.table("vhse_test.txt", header = TRUE)
set.seed(13)
rand.num <- as.vector(sample(1:13253,1000))
vhse.linpred <- vhse.test$linear.pred
zscale.linpred <- z.test$linear.pred
observed <- vhse.test$observed

vhse.lindist <- abs(vhse.linpred - observed)
zscale.lindist <- abs(zscale.linpred - observed)

distance <- data.frame(observed[rand.num], vhse.lindist[rand.num], zscale.lindist[rand.num])
distance <- data.frame(observed = c(distance[,"observed.rand.num."],distance[,"observed.rand.num."]), 
                       lin.dist = c(distance[,"vhse.lindist.rand.num."],distance[,"zscale.lindist.rand.num."]))
distance$class <- "VHSE"
distance[1001:2000,"class"] <- "Z-Scale"
distance <- distance[c(1,3,2)]

vhse.lin <- distance[1:1000,]
zscale.lin <- distance[1001:2000,]

vhse.lm <- lm(vhse.lin$lin.dist ~ poly(vhse.lin$observed, 2, raw = TRUE))
summary(vhse.lm)
zscale.lm <- lm(zscale.lin$lin.dist ~ poly(zscale.lin$observed, 2, raw = TRUE))
summary(zscale.lm)

# included ".rand.num. because using my rand.num changes column names
lin.plot <- ggplot(distance, aes(x = observed, y = lin.dist, color = class)) + 
  geom_point() + 
  labs(x = "observed", y = "linear distance", title = "Distance from Observed Values - Linear Model") +
  scale_color_discrete(name = "AA Descriptor") +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) + 
  stat_smooth(method = "lm", se = FALSE, fill = NA, 
              formula = y~poly(x,2), colour = "black") + facet_grid(~class)


lin.plot

lin.hist <- ggplot(distance, aes(x=abs(distance$lin.dist - distance$observed), fill=class)) + 
  geom_histogram(binwidth = 0.05) + 
  labs(x = "Distance", title = "Distance Between Predicted and Observed Values - Linear Model")+
  facet_grid(~class) + 
  theme(plot.title = element_text(hjust = 0.5))
lin.hist
######################################################################
# svm
set.seed(13)
rand.num <- as.vector(sample(1:13253,1000))
vhse.svmpred <- vhse.test$svm.pred
zscale.svmpred <- z.test$svm.pred
observed <- vhse.test$observed

vhse.svmdist <- abs(vhse.svmpred - observed)
zscale.svmdist <- abs(zscale.svmpred - observed)

distance <- data.frame(observed[rand.num], vhse.svmdist[rand.num], zscale.svmdist[rand.num])
distance <- data.frame(observed = c(distance[,"observed.rand.num."],distance[,"observed.rand.num."]), 
                       svm.dist = c(distance[,"vhse.svmdist.rand.num."],distance[,"zscale.svmdist.rand.num."]))
distance$class <- "VHSE"
distance[1001:2000,"class"] <- "Z-Scale"
distance <- distance[c(1,3,2)]

vhse.svm <- distance[1:1000,]
zscale.svm <- distance[1001:2000,]

vhse.svm <- lm(vhse.svm$svm.dist ~ poly(vhse.svm$observed, 2, raw = TRUE))
summary(vhse.svm)
zscale.svm <- lm(zscale.svm$svm.dist ~ poly(zscale.svm$observed, 2, raw = TRUE))
summary(zscale.svm)

# included ".rand.num. because using my rand.num changes column names
svm.plot <- ggplot(distance, aes(x = observed, y = svm.dist, color = class)) + 
  geom_point(alpha = 0.5) + 
  labs(x = "observed", y = "svm distance", title = "Distance from Observed Values - SVM Model") +
  scale_color_discrete(name = "AA Descriptor") +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) +
  stat_smooth(method = "lm", se = FALSE, fill = NA,
              formula = y~poly(x, 2), colour = "black") + facet_grid(~class)

svm.plot



######################################################################
# Tree
set.seed(13)
rand.num <- as.vector(sample(1:13253,1000))
vhse.treepred <- vhse.test$tree.pred
zscale.treepred <- z.test$tree.pred
observed <- vhse.test$observed

vhse.treedist <- abs(vhse.treepred - observed)
zscale.treedist <- abs(zscale.treepred - observed)

distance <- data.frame(observed[rand.num], vhse.treedist[rand.num], zscale.treedist[rand.num])
distance <- data.frame(observed = c(distance[,"observed.rand.num."],distance[,"observed.rand.num."]), 
                       tree.dist = c(distance[,"vhse.treedist.rand.num."],distance[,"zscale.treedist.rand.num."]))
distance$class <- "VHSE"
distance[1001:2000,"class"] <- "Z-Scale"
distance <- distance[c(1,3,2)]

vhse.tree <- distance[1:1000,]
zscale.tree <- distance[1001:2000,]

vhse.tree <- lm(vhse.tree$tree.dist ~ poly(vhse.tree$observed, 2, raw = TRUE))
summary(vhse.tree)
zscale.tree <- lm(zscale.tree$tree.dist ~ poly(zscale.tree$observed, 2, raw = TRUE))
summary(zscale.tree)

# included ".rand.num. because using my rand.num changes column names
tree.plot <- ggplot(distance, aes(x = observed, y = tree.dist, color = class)) + 
  geom_point() + 
  labs(x = "observed", y = "tree distance", title = "Distance from Observed Values - Tree Model") +
  scale_color_discrete(name = "AA Descriptor") +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) + 
  stat_smooth(method = "lm", se = FALSE, fill = NA,
              formula = y~poly(x, 2), colour = "black") + facet_grid(~class)


tree.hist <- ggplot(distance, aes(x=abs(distance$tree.dist - distance$observed), fill=class)) + 
  geom_histogram(binwidth = 0.05) + 
  labs(x = "Distance", title = "Distance Between Predicted and Observed Values - Tree Model")+
  facet_grid(~class) + 
  theme(plot.title = element_text(hjust = 0.5))

tree.hist
######################################################################
# K-Nearest Neighbours
set.seed(13)
rand.num <- as.vector(sample(1:13253,1000))
vhse.knnpred <- vhse.test$knn.pred
zscale.knnpred <- z.test$knn.pred
observed <- vhse.test$observed

vhse.knndist <- abs(vhse.knnpred - observed)
zscale.knndist <- abs(zscale.knnpred - observed)

distance <- data.frame(observed[rand.num], vhse.knndist[rand.num], zscale.knndist[rand.num])
distance <- data.frame(observed = c(distance[,"observed.rand.num."],distance[,"observed.rand.num."]), 
                       knn.dist = c(distance[,"vhse.knndist.rand.num."],distance[,"zscale.knndist.rand.num."]))
distance$class <- "VHSE"
distance[1001:2000,"class"] <- "Z-Scale"
distance <- distance[c(1,3,2)]


vhse.knn <- distance[1:1000,]
zscale.knn <- distance[1001:2000,]

vhse.knn <- lm(vhse.knn$knn.dist ~ poly(vhse.knn$observed, 2, raw = TRUE))
summary(vhse.knn)
zscale.knn <- lm(zscale.knn$knn.dist ~ poly(zscale.knn$observed, 2, raw = TRUE))
summary(zscale.knn)

# included ".rand.num. because using my rand.num changes column names
knn.plot <- ggplot(distance, aes(x = observed, y = knn.dist, color = class)) + 
  geom_point() + 
  labs(x = "observed", y = "knn distance", title = "Distance from Observed Values - KNN Model") +
  scale_color_discrete(name = "AA Descriptor") +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) + 
  stat_smooth(method = "lm", se = FALSE, fill = NA,
              formula = y~poly(x, 2), colour = "black") + facet_grid(~class)

knn.plot


knn.hist <- ggplot(distance, aes(x=abs(distance$knn.dist - distance$observed), fill=class)) + 
  geom_histogram(binwidth = 0.05) + 
  labs(x = "Distance", title = "Distance Between Predicted and Observed Values - KNN Model")+
  facet_grid(~class) + 
  theme(plot.title = element_text(hjust = 0.5))
knn.hist

grid.arrange(lin.plot, svm.plot, tree.plot, knn.plot, 
             nrow=2, top = "Distance from Observed Values of Different Models for VHSE and Z-Scale AADS")

######################################################################