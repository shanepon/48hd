######################################################################
# Name: descriptor_comparisons.r
# Author: Shane Pon
# Date: September 2
# Function: compares predicted values of each method for both descriptors 
#           for both descriptors against each other
# Input: vhse_test.txt (contains predicted values from machine learning algorithms)
# Output: plots of the predicted vs observed for algorithms superimposed on each other
# Usage: Run script after setting working directory 

######################################################################
# compares descriptors and different machine learning methods
library(ggplot2)
library(gridExtra)
setwd("/Users/shanepon/Desktop/Shane Files/6.) excel table")
vhse.test <- read.table("vhse_test.txt", header = TRUE)
z.test <- read.table("z_test.txt", header = TRUE)

set.seed(21)
rand.num <- as.vector(sample(1:13253,1000))
######################################################################
# compare linear model for VHSE to Z-Scale
vhse.linpred <- ggplot(vhse.test[rand.num,], aes(x=observed, y=linear.pred)) + 
              geom_point() + 
              labs(x="observed", y="linear prediction") + 
              xlim(-4,-1.75) + ylim(-4, -2) + 
              geom_abline(col = "steelblue", size = 1) 
# vhse.linpred

zscale.linpred <- ggplot(z.test[rand.num,], aes(x=observed, y=linear.pred)) + 
                  geom_point() + 
                  labs(x="observed", y="linear prediction") +
                  xlim(-4, -1.75) + ylim(-4, -2) + 
                  geom_abline(col = "steelblue", size = 1) 
# zscale.linpred
grid.arrange(vhse.linpred, zscale.linpred, 
             nrow=1, top = "VHSE (left) and Z-Scale (right) Linear Predictions vs Observed Values")



######################################################################
# compare SVM model for VHSE to Z-Scale
vhse.svmpred <- ggplot(vhse.test[rand.num,], aes(x=observed, y=svm.pred)) + 
  geom_point() +
  labs(x="observed", y="svm prediction") +
  xlim(-4,-1.75) + ylim(-4, -2) +
  geom_abline(col = "steelblue", size = 1) 

# vhse.svmpred

zscale.svmpred <- ggplot(z.test[rand.num,], aes(x=observed, y=svm.pred)) + 
  geom_point() + 
  labs(x="observed", y="linear prediction") +
  xlim(-4, -1.75) + ylim(-4, -2) + 
  geom_abline(col = "steelblue", size = 1)

# zscale.linpred
grid.arrange(vhse.svmpred, zscale.svmpred, 
             nrow=1, top = "VHSE (left) and Z-Scale (right) SVM Predictions vs Observed Values")




######################################################################
# compare tree model for VHSE to Z-Scale
vhse.treepred <- ggplot(vhse.test[rand.num,], aes(x=observed, y=tree.pred)) + 
  geom_point() +
  labs(x="observed", y="tree prediction") +
  xlim(-4,-1.75) + ylim(-4, -2) +
  geom_abline(col = "steelblue", size = 1) 

# vhse.treepred

zscale.treepred <- ggplot(z.test[rand.num,], aes(x=observed, y=tree.pred)) + 
  geom_point() + 
  labs(x="observed", y="tree prediction") +
  xlim(-4, -1.75) + ylim(-4, -2) + 
  geom_abline(col = "steelblue", size = 1)

# zscale.treepred
grid.arrange(vhse.treepred, zscale.treepred, 
             nrow=1, top = "VHSE (left) and Z-Scale (right) Tree Predictions vs Observed Values")



######################################################################
# compare knn model for VHSE to Z-Scale
vhse.knnpred <- ggplot(vhse.test[rand.num,], aes(x=observed, y=knn.pred)) + 
  geom_point() +
  labs(x="observed", y="k-nearest neighbours prediction") +
  xlim(-4,-1.75) + ylim(-4, -2) +
  geom_abline(col = "steelblue", size = 1) 

# vhse.knnpred

zscale.knnpred <- ggplot(z.test[rand.num,], aes(x=observed, y=knn.pred)) + 
  geom_point() + 
  labs(x="observed", y="k-nearest neighbours prediction") +
  xlim(-4, -1.75) + ylim(-4, -2) + 
  geom_abline(col = "steelblue", size = 1) 

# zscale.knnpred
grid.arrange(vhse.knnpred, zscale.knnpred, 
             nrow=1, top = "VHSE (left) and Z-Scale (right) K-Nearest Neighbours Predictions vs Observed Values")



######################################################################






