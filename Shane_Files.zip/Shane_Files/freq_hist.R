 ###################################################################
# Name: freq_hist.R
# Author: Shane Pon
# Date Written: July 10
# Function: Generates a plot of all the combination frequencies 
# Procedure: Create data frame combining all three combination text files, then generate a plot
#            from from that data frame and annonate it appropriately 
# Input: combination1, combination2, combination3 .txt files produced from combinations.py
# Output: A plot displaying frequencies of each of the combinations
# How to use: Run script after changing working directory; Don't forget to set the working directory


###################################################################
# Load ggplot2 library and set directory
# Don't forget to set the working directory
setwd("/.../.../...")
library(ggplot2)

# Create data frame of combinations with frequencies and position number
combo1 <- read.table("combinations1.txt", header=TRUE)
combo2 <- read.table("combinations2.txt", header=TRUE)
combo3 <- read.table("combinations3.txt", header=TRUE)

combo1 <- data.frame(x = combo1$Combination, y = combo1$Frequency, Type = as.factor("Position 1"))
combo2 <- data.frame(x = combo2$Combination, y = combo2$Frequency, Type = as.factor("Position 2"))
combo3 <- data.frame(x = combo3$Combination, y = combo3$Frequency, Type = as.factor("Position 3"))

# make one table
combo.merged <- rbind(combo1, combo2, combo3)
combo.merged <- combo.merged[order(combo.merged$x),]

# include the index of each combination 
# with breaks of ten in between each new letter
index = 0

for (i in 1:1200) {
  if ((i >= 60) && (i%%60 == 1)){
    index = index + 10

  }
  else if (i %% 3 == 1) {
    index = index + 1
    combo.merged$Index[i] <- index

  }
  else if (i %% 3 == 0) {
    combo.merged$Index[i] <- index

  }
  else if (i %% 3 == 2) {
    combo.merged$Index[i] <- index

  }
}

# manually correct the index 
#C
combo.merged[61,"Index"] <-30
#D
combo.merged[121,"Index"] <-59
#E
combo.merged[181,"Index"] <-78
#F
combo.merged[241,"Index"] <-117
#G
combo.merged[301,"Index"] <-146
#H
combo.merged[361,"Index"] <-175
#I
combo.merged[421,"Index"] <-204
#K
combo.merged[481,"Index"] <-233
#L
combo.merged[541,"Index"] <-262
#M
combo.merged[601,"Index"] <-291
#N 
combo.merged[661,"Index"] <-320
#P
combo.merged[721,"Index"] <-349
#Q
combo.merged[781,"Index"] <-378
#R
combo.merged[841,"Index"] <-407
#S
combo.merged[901,"Index"] <-436
#T
combo.merged[961,"Index"] <-465
#V
combo.merged[1021,"Index"] <-494
#W
combo.merged[1081,"Index"] <-523
#Y
combo.merged[1141,"Index"] <-552

# Create plot
freq <- ggplot(combo.merged, aes(x=combo.merged$Index, y=combo.merged$y, colour=Type)) +
  geom_point() +
  labs(x="Acid Combination", y="Frequency") +
  ggtitle("Frequency of Amino Acid Combinations") +
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_x_discrete(breaks = seq(0, 100, 20))

# Annotate the combinations by the letter they begin with
freq <- freq + annotate("text", label = "A", x = 10, y = 0, color = "black") +
  annotate("text", label = "C", x = 40, y = 0, color = "black") +
  annotate("text", label = "D", x = 69, y = 0, color = "black") +
  annotate("text", label = "E", x = 92, y = 0, color = "black") +
  annotate("text", label = "F", x = 127, y = 0, color = "black") +
  annotate("text", label = "G", x = 155, y = 0, color = "black") +
  annotate("text", label = "H", x = 185, y = 0, color = "black") +
  annotate("text", label = "I", x = 214, y = 0, color = "black") +
  annotate("text", label = "K", x = 243, y = 0, color = "black") +
  annotate("text", label = "L", x = 272, y = 0, color = "black") +
  annotate("text", label = "M", x = 301, y = 0, color = "black") +
  annotate("text", label = "N", x = 330, y = 0, color = "black") +
  annotate("text", label = "P", x = 359, y = 0, color = "black") +
  annotate("text", label = "Q", x = 388, y = 0, color = "black") +
  annotate("text", label = "R", x = 417, y = 0, color = "black") +
  annotate("text", label = "S", x = 446, y = 0, color = "black") +
  annotate("text", label = "T", x = 475, y = 0, color = "black") +
  annotate("text", label = "V", x = 504, y = 0, color = "black") +
  annotate("text", label = "W", x = 533, y = 0, color = "black") +
  annotate("text", label = "Y", x = 561, y = 0, color = "black")
  

print(freq)
