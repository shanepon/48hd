###########################################################################
# Name: histograms.R
# Author: Shane Pon 
# Date: Early July 
# Function: Create histogram of frequencies for each letter in each position
# Input: text file count1-4
# Output: Generates histogram and scatterplot comparing counts of acids in each position 
# How to use: run the file and change working directory 







###########################################################################
setwd("/Users/shanepon/Desktop/Shane Files/count")

 
count1 <- read.table("count1.txt", header=TRUE)
count2 <- read.table("count2.txt", header=TRUE)
count3 <- read.table("count3.txt", header=TRUE)
count4 <- read.table("count4.txt", header=TRUE)
par(mfrow=c(2,2))


histogram1 <- barplot(count1$Frequency, names.arg = count1$Amino_Acid, 
                      ylim = c(0,6000),
                      ylab = "Frequency", main = "Frequency in First Position", 
                      las = 2, col = 'red')
text(histogram1, y = count1$Frequency, label = count1$Frequency,
     pos = 3, cex = 0.5)


histogram2 <- barplot(count2$Frequency, names.arg = count2$Amino_Acid, 
                      ylim = c(0, 5800),
                      ylab = "Frequency", main = "Frequency in Second Position", 
                      las = 2, col = 'dark blue')
text(histogram2, y = count2$Frequency, label = count2$Frequency,
     pos = 3, cex = 0.5)


histogram3 <- barplot(count3$Frequency, names.arg = count3$Amino_Acid, 
                      ylim = c(0, 6000),
                      ylab = "Frequency", main = "Frequency in Third Position", 
                      las = 2, col = 'dark green')
text(histogram3, y = count3$Frequency, label = count3$Frequency,
     pos = 3, cex = 0.5)

histogram4 <- barplot(count4$Frequency, names.arg = count4$Amino_Acid, 
                      ylim = c(0, 5600),
                      ylab = "Frequency", main = "Frequency in Fourth Position", 
                      las = 2, col = 'gold')
text(histogram4, y = count4$Frequency, label = count4$Frequency,
     pos = 3, cex = 0.5)

df = data.frame(count1, count2, count3, count4)

ggplot(data = df) + 
  geom_point(aes(x=df$Position_1, y=df$Frequency, shape="Position 1"),col='green') +
  geom_point(aes(x=df$Position_2, y=df$Frequency.1, shape="Position 2"),  col='red') +
  geom_point(aes(x=df$Position_3, y=df$Frequency.2, shape="Position 3"),  col='blue') +
  geom_point(aes(x=df$Position_4, y=df$Frequency.3, shape="Position 4"), col='orange') +
  labs(x = "Amino Acid", y = "Frequency") +
  scale_color_manual(name = "Position",values = df$Amino_Acid) +
  ggtitle("Frequency of Amino Acids in Each Position") +
  theme(plot.title = element_text(hjust = 0.5))
  





