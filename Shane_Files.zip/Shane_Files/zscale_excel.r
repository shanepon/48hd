##################################################################
# Name: zscale_excel.r 
# Author: Shane Pon
# Date: August 30
# Function: Produce predicted values and compile into table
# Input: z_encoding.txt (z-scale encoded sequences without zero values removed)
# Output: training/test set, and test set predictions
# Run script after setting the working directory



##################################################################
# create excel sheet with observed and predicted values 
setwd("/Users/shanepon/Desktop/Shane Files/6.) excel table")
library(caret)
library(kernlab)
library(DAAG)
library(tibble)
# comment which script z_encoding.txt is the output of 
zscale <- read.table("z_encoding.txt", header = TRUE)
zscale <- subset(zscale, log.value > -4) 

set.seed(1) 
rand.num <- as.vector(sample(1:66266, 53013))

train_z <- zscale[rand.num,] 
colnames(train_z)[13] <- "observed"
train_z$linear.pred <- NA 
train_z$svm.pred <- NA 
train_z$tree.pred <- NA 
train_z$knn.pred <- NA 

test_z <- zscale[-rand.num,]
colnames(test_z)[13] <- "observed"

test_z$linear.pred <- NA
test_z$svm.pred <- NA
test_z$tree.pred <- NA
test_z$knn.pred <- NA

#################################################################################
# first supervised learning: linear regression 
z.lin.model <- lm(observed~., data = train_z[,1:13])
z.lin.predicted = predict.lm(z.lin.model, test_z[,1:12], interval = "prediction", level = 0.95)
test_z[,"linear.pred"] <- z.lin.predicted[,1]

#################################################################################
# second supervised learning: support vector machines
library(e1071)
system.time(
  z.svm.model <- svm(observed~., data = train_z[,1:13])
  )
z.svm.predicted <- predict(z.svm.model, test_z[,1:12], interval = "prediction")
test_z[,"svm.pred"] <- z.svm.predicted[,1]




#################################################################################
# third supervised learning: decision trees
library(tree)
z.tree.model <- tree(observed~., data = train_z[,1:13], method = "anova")
z.tree.predicted <- predict(z.tree.model, test_z[,1:12], interval = "prediction")
test_z[,"tree.pred"] <- z.tree.predicted

#################################################################################
# fourth supervised learning: k nearest neighbour
system.time(
  z.knn.model <- train(observed~., data = train_z[,1:13], method = "knn")
  )
z.knn.predicted <- predict(z.knn.model, test_z[,1:12], interval = "prediction")
test_z[,"knn.pred"] <- z.knn.predicted


#################################################################################
# combine all into one text file
z_results <- rbind(train_z, test_z)
write.table(z_results, "z_results.txt")











