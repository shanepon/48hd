########################################################
# look at extreme values in MLinput distribution 
# train the model on the extreme values 
setwd("/Users/shanepon/48hd/extreme_values")
library(dplyr)
library(tidyr) 
library(ggplot2) 
library(caret)
########################################################
# Preprocess the data 
MLinput <- read.table("MLinput_log.txt", header = TRUE)

vhse <- read.table("nonzero_vhse.txt", header = TRUE) %>%
        subset(., observed > -2.4 | observed < -3.3)
zscale <- read.table("z_encoding.txt", header = TRUE) %>% 
          subset(., observed > -4) %>% 
          subset(., observed > -2.4 | observed < -3.3)

# rand.num is 80% of data for training
set.seed(12)
rand.num <- as.vector(sample(1:6632, 5305))
vhse.train <- vhse[rand.num,]
vhse.test <- vhse[-rand.num,]

zscale.train <- zscale[rand.num,]
zscale.test <- zscale[-rand.num,]

rm(vhse)
rm(zscale)
########################################################
# linear model 
vhse.lm <- lm(observed~., vhse.train)
vhse.lm.pred <- predict.lm(vhse.lm, vhse.test[,1:32], interval = "prediction")
vhse.test[, "linear.pred"] <- vhse.lm.pred[,1]
rm(vhse.lm)
rm(vhse.lm.pred)

zscale.lm <- lm(observed~., zscale.train)
zscale.lm.pred <- predict.lm(zscale.lm, zscale.test[,1:12], interval = "prediction")
zscale.test[, "linear.pred"] <- zscale.lm.pred[,1]
rm(zscale.lm)
rm(zscale.lm.pred)


########################################################
# support vector machines
library(e1071)
system.time(
  vhse.svm <- svm(observed~., data = vhse.train)
  )
vhse.svm.pred <- predict(vhse.svm, vhse.test[,1:32], interval = "prediction")
vhse.test[,"svm.pred"] <- vhse.svm.pred
rm(vhse.svm)
rm(vhse.svm.pred)


system.time(
  zscale.svm <- svm(observed~., data = zscale.train)
)
zscale.svm.pred <- predict(zscale.svm, zscale.test[,1:12], interval = "prediction")
zscale.test[,"svm.pred"] <- zscale.svm.pred
rm(zscale.svm)
rm(zscale.svm.pred)


#################################################################################
# decision trees
library(tree)
vhse.tree <- tree(observed~., data = vhse.train, method = "anova")
vhse.tree.pred <- predict(vhse.tree, vhse.test[,1:32], interval = "prediction")
vhse.test[,"tree.pred"] <- vhse.tree.pred
rm(vhse.tree)
rm(vhse.tree.pred)

zscale.tree <- tree(observed~., data = zscale.train, method = "anova")
zscale.tree.pred <- predict(zscale.tree, zscale.test[,1:12], interval = "prediction")
zscale.test[,"tree.pred"] <- zscale.tree.pred
rm(zscale.tree)
rm(zscale.tree.pred)

#################################################################################
# k-nearest neighbors
system.time(
  vhse.knn <- train(observed~., data = vhse.train, method = "knn")
  )
vhse.knn.pred <- predict(vhse.knn, vhse.test[,1:32], interval = "prediction")
vhse.test[,"knn.pred"] <- vhse.knn.pred
rm(vhse.knn)
rm(vhse.knn.pred)


system.time(
  zscale.knn <- train(observed~., data = zscale.train, method = "knn")
)
zscale.knn.pred <- predict(zscale.knn, zscale.test[,1:12], interval = "prediction")
zscale.test[,"knn.pred"] <- zscale.knn.pred
rm(zscale.knn)
rm(zscale.knn.pred)






